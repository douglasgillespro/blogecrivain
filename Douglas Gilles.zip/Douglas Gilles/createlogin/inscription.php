<?php 
try
{
    $bdd = new PDO('mysql:host=localhost;dbname=test', 'root', 'root');
}
catch(Exception $e)
{
    die('Erreur : '.$e->getMessage());
}

$erreur=null;
if (isset($_POST['submit'])){
    $pseudo = htmlspecialchars($_POST['pseudo']);
    $password = htmlspecialchars($_POST['password']);
    $confirm_pass = htmlspecialchars($_POST['confirm_pass']);
    $login = htmlspecialchars($_POST['login']);
    if ($pseudo && $password && $confirm_pass && $login){
        if(preg_match("#^[a-zA-Z0-9_]{3,16}$#", $pseudo )){
                if(strlen($password)>=6){
                    if ($password == $confirm_pass) {
                        $password = password_hash($password, PASSWORD_DEFAULT);
                        //Insertion dans la base de données
                        $insertmbr = $bdd->prepare('INSERT INTO users (pseudo, password, login) VALUES (?, ?, ?)');
                        $insertmbr->execute(array($pseudo, $password, $login));
                        $erreur = "Votre compte a bien été créé :) !";
                    } else $erreur = "Les mots de passe ne sont pas identiques !";
                } else $erreur = "Le mot de passe est trop court !";
        } else $erreur = "Le pseudo n'est pas valide !";
    } else $erreur = "Veuillez remplir tous les champs !";
}
?>
<h1>Espace Membre</h1>
<form action="" method="post">
    <!-- Douglas -->
	<label for="pseudo">Pseudo</label>
	<input type="text" name="pseudo" placeholder="pseudo"><br>
    <!-- admin -->
	<label for="login">login</label>
	<input type="text" name="login" placeholder="login"><br>
    <!-- admin1234 -->
	<label for="password">Mot de passe</label> 
	<input type="password" name="password" id="password"><br>
	<label for="confirm_pass">Confirmation du mot de passe</label>
	<input type="password" name="confirm_pass" id="confirm_pass"><br>
	<input type="submit" name="submit" value="M'inscrire">
</form>
<?php
    if(isset($erreur)){
        echo $erreur;
    }
    var_dump($_POST);
?>